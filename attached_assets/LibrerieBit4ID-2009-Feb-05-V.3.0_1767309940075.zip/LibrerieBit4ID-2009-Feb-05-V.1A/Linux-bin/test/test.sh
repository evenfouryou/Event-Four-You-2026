#!/bin/sh
chmod +x test
./test "$@"
