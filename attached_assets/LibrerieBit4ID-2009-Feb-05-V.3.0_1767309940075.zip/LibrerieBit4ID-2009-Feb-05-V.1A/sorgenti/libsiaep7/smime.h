#ifndef _SMIME_H_
#define _SMIME_H_ 1


#ifdef __cplusplus
extern "C" {
#endif
 

#ifdef __cplusplus
};
#endif



#endif //_SMIME_H_
