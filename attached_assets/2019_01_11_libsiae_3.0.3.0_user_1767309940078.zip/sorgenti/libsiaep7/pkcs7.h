#ifndef PKCS7_H
#define PKCS7_H

#include "libsiaecard.h"
#include "libsiaep7.h"

#ifdef __cplusplus
extern "C" {
#endif
 

#ifdef __cplusplus
};
#endif

#endif // PKCS7_H




